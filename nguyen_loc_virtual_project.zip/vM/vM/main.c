//
//  virt_mem.c
//  virt_mem
//
//  Created by William McCarthy on 3/23/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256


//-------------------------------------------------------------------
int pageTable[256];
int pageTableFrame[256];
int TLBPageNum[16];
int TLBFrameNum[16];
int physicalAddress[BUFLEN][FRAME_SIZE];
int nextAvailablePage=0;
int nextAvailableFrame=0;
int pageFault=0;
int tlbHit=0;
int tlbEntry=0;
unsigned char buffer[256];
signed char memoryValue;
unsigned int getpage(size_t x) { return (0xff00 & x) >> 8; }
unsigned int getoffset(unsigned int x) { return (0xff & x); }
unsigned int page, offset, physical_add, frame = 0, frameNumber;
unsigned int logic_add;                  // read from file address.txt
unsigned int virt_add, phys_add, value=0;
void getBackUp(int pageNumber);
unsigned int insertTLB(int pageNumber, int pageFrame);
void getpage_offset(unsigned int x) {
    unsigned int page = getpage(x);
    unsigned int offset = getoffset(x);
    printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
           (page << 8) | getoffset(x), page * 256 + offset);
}
unsigned int getPageEntry(int page){
    for (int i =0;i<nextAvailablePage;i++){
        if (pageTable[i]== page){
            frameNumber= pageTableFrame[i];
            insertTLB(page,frameNumber);
            return frameNumber;
            
        }
    }
    getBackUp(page);
    frameNumber= nextAvailableFrame-1;
    insertTLB(page,frameNumber);
    return frameNumber;
    
}
unsigned int insertTLB(int pageNumber, int pageFrame){
    for (int i =0;i<tlbEntry;i++){
        if (TLBPageNum[i]== pageNumber){
            return frameNumber;
        }
    }
    if(tlbEntry<16){
        TLBPageNum[tlbEntry]= pageNumber;
        TLBFrameNum[tlbEntry]= frameNumber;
        return frameNumber;
    }
    else {
        tlbEntry=0;
        TLBFrameNum[tlbEntry]= pageNumber;
        TLBFrameNum[tlbEntry]=pageFrame;
//        for (int i =0;i<15;i++){
//            int tlbPageTemp[15];
//            int tlbFrameTemp[15];
//            tlbPageTemp[i]=TLBPageNum[i+1];
//            tlbFrameTemp[i]=TLBFrameNum[i+1];
        }
    return frameNumber;
}
void getBackUp(int pageNumber){
    FILE *backingStore= fopen ("backing_store.bin","r");
    if (fseek(backingStore, pageNumber * BUFLEN, SEEK_SET) != 0) {
        fprintf(stderr, "Error seeking in backing store\n");
    }
    if (fread(buffer, sizeof(signed char), BUFLEN, backingStore) == 0) {
        fprintf(stderr, "Error reading from backing store\n");
    }
    for (int i =0;i<255;i++){
        physicalAddress[nextAvailableFrame][i]=buffer[i];
    }
        pageTable[nextAvailablePage]= pageNumber;
        pageTableFrame[nextAvailablePage]=nextAvailableFrame;
        nextAvailablePage++;
        nextAvailableFrame++;
        pageFault++;
    
}
int main(int argc, const char * argv[]) {
    FILE* fadd = fopen("addresses.txt", "r");
    if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }
    FILE* fcorr = fopen("correct.txt", "r");
    if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }
    // not quite correct -- should search page table before creating a new entry
    //   e.g., address # 25 from addresses.txt will fail the assertion
    // TODO:  add page table code
    // TODO:  add TLB code
    while (frame < 1000) {
        fscanf(fcorr, "%s %s %d %s %s %d %s %d", buffer, buffer, &virt_add,
               buffer, buffer, &phys_add, buffer, &value);  // read from file correct.txt
        
        fscanf(fadd, "%d", &logic_add);  // read from file address.txt
        page = getpage(logic_add);
        offset = getoffset(logic_add);
        int frameNumber= getPageEntry(page);
        physical_add = frameNumber * FRAME_SIZE + offset;
        //memoryValue = ( offset + physical_add);
        memoryValue= physicalAddress[frameNumber][offset];
        assert(physical_add == phys_add);
        // todo: read BINARY_STORE and confirm value matches read value from correct.txt
        printf("logical: %5u (page:%3u, offset:%3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
        if (frame % 5 == 0) { printf("\n"); }
        frame ++;
    }
    double pageFaultFate = pageFault / 1000.0;
    printf("Page Fault : %u\n",pageFault);
    printf("page Fault Rate= %.3f\n",pageFaultFate);
    fclose(fcorr);
    fclose(fadd);
    return 0;
}
