public class Customer implements Runnable {
    public static final int COUNT = 5;    // number of threads
    public static  boolean canRun = false;
    private int numOfResources;     // N different resources
    private int[] maxDemand;        // maximum this thread will demand
    private int customerNum;        // customer number
    private int[] request;          // request it is making

    private java.util.Random rand;  // random number generator

    private Bank theBank;           // synchronizing object
    public Customer(int customerNum, int[] maxDemand, Bank theBank) {
        this.customerNum = customerNum;
        this.maxDemand = new int[3];
        this.theBank = theBank;

        System.arraycopy(maxDemand,0,this.maxDemand,0,3);
        numOfResources = 3;
        request = new int[3];
        rand = new java.util.Random();
    }

    public void run() {
        canRun = false;
        while (canRun) {
            try {
                SleepUtilities.nap();
                for (int i = 0; i < numOfResources; i++) {
                    request[i] = rand.nextInt(maxDemand[i] + 1);
                }

                if (theBank.requestResources(customerNum, request)) {   // if customer can proceed
                    SleepUtilities.nap();   // use and release the resources
                    theBank.releaseResources(customerNum, request);
                }
            } catch (InterruptedException ie) {

            }
        }
    }
}
