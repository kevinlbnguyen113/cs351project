import java.io.*;
import java.util.*;

import static java.lang.System.*;

public class BankImpl implements Bank {
    private int n;            // the number of threads in the system
    private int m;            // the number of resources

    private int[] available;    // the amount available of each resource
    private int[][] maximum;    // the maximum demand of each thread
    private int[][] allocation;    // the amount currently allocated to each thread
    private int[][] need;        // the remaining needs of each thread
    boolean safestate = false;

    private void showAllMatrices(int[][] alloc, int[][] max, int[][] need, String msg) {
        // todo
        System.out.print("\nAllocation = \t");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(alloc[i][j] + " ");
            System.out.print(alloc[i][m - 1] + "]");
        }
        System.out.print("\nMax = \t\t");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(max[i][j] + " ");
            System.out.print(max[i][m - 1] + "]");
        }
        System.out.print("\nNeed = \t\t");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(need[i][j] + " ");
            System.out.print(need[i][m - 1] + "]");
        }
    }

    private void showMatrix(int[][] matrix, String title, String rowTitle) {
        // todo
    }

    private void showVector(int[] vect, String msg) {
        // todo
    }

    public BankImpl(int[] resources) {
        m = resources.length;
        n = Customer.COUNT;
        available = new int[m];
        arraycopy(resources, 0, available, 0, m);
        maximum = new int[Customer.COUNT][];
        allocation = new int[Customer.COUNT][];
        need = new int[Customer.COUNT][];


    }
    public void addCustomer(int threadNum, int[] allocated, int[] maxDemand) {
        maximum[threadNum] = new int[m];
        allocation[threadNum] = new int[m];
        need[threadNum] = new int[m];
        System.arraycopy(maxDemand, 0, maximum[threadNum], 0, 3);
        System.arraycopy(allocated, 0, allocation[threadNum], 0, 3);
        //System.arraycopy(maxDemand, 0, need[threadNum], 0, 3);
        for (int i =0;i<3;i++) {
            need[threadNum][i] = maximum[threadNum][i] - allocation[threadNum][i];
        }

    }

    public void getState() {        // output state for each thread
        System.out.print("Available = \t[");
        for (int i = 0; i < m - 1; i++)
            System.out.print(available[i] + " ");
        System.out.println(available[m - 1] + "]");
        System.out.print("\nAllocation  \t\tMax\t\t\t\t\tNeed\n");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(allocation[i][j] + " ");
            System.out.print(allocation[i][m - 1] + "]\t\t\t\t");
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(maximum[i][j] + " ");
            System.out.print(maximum[i][m - 1] + "]\t\t\t\t");
            System.out.print("[");
            for (int j = 0; j < m - 1; j++)
                System.out.print(need[i][j] + " ");
            System.out.print(need[i][m - 1] + "]\n");
        }

        System.out.println(" ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 1; j++) {
                if (need[i][j] <= available[j] && need[i][j + 1] <= available[j + 1] && need[i][j + 2] <= available[j + 2]) {
                    safestate = true;
                }
            }

        }
        System.out.println();
    }

    private boolean isSafeState(int threadNum, int[] request) {
        System.out.print("\n Customer # " + threadNum + " requesting ");
        for (int i = 0; i < m; i++) System.out.print(request[i] + " ");

        System.out.print("Available = ");
        for (int i = 0; i < m; i++)
            System.out.print(available[i] + "  ");
        for (int i = 0; i < m; i++)
            if (request[i] > available[i]) {
                System.err.println("DENIED");
                return false;
            }
        boolean[] canFinish = new boolean[n];
        for (int i = 0; i < n; i++)
            canFinish[i] = false;
        int[] avail = new int[m];
        System.arraycopy(available, 0, avail, 0, available.length);
        for (int i = 0; i < m; i++) {
            avail[i] -= request[i];
            need[threadNum][i] -= request[i];
            allocation[threadNum][i] += request[i];
        }
        return true;
    }
    public synchronized boolean requestResources(int threadNum, int[] request) {
        if (!isSafeState(threadNum, request)) {
            return false;
        }
        for (int i = 0; i < m; i++) {
            available[i] -= request[i];
            allocation[threadNum][i] += request[i];
            need[threadNum][i] = maximum[threadNum][i] - allocation[threadNum][i];

        }

        return true;
    }

    public synchronized void releaseResources(int threadNum, int[] release) {
        System.out.print("\n Customer # " + threadNum + " releasing ");
        for (int i = 0; i < m; i++) System.out.print(release[i] + " ");
        for (int i = 0; i < m; i++) {
            available[i] += release[i];
            allocation[threadNum][i] -= release[i];
            need[threadNum][i] = maximum[threadNum][i] + allocation[threadNum][i];
        }
        System.out.print("Available = ");
        for (int i = 0; i < m; i++)
            System.out.print(available[i] + "  ");
        System.out.print("Allocated = [");
        for (int i = 0; i < m; i++)
            System.out.print(allocation[threadNum][i] + "  ");
        System.out.print("]");
    }
}