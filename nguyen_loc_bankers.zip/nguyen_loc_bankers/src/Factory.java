    // Factory.java
    //
    // Factory class that creates the bank and each bank customer
    // Usage:  java Factory 10 5 7

    import java.io.*;
    import java.util.*;

    public class Factory {
        public static void main(String[] args) throws java.io.IOException {
            String filename = "/Users/Tram-AnhTran/Desktop/BankerProblem/src/infile.txt";
            int nResources = args.length;
            int[] resources = new int[]{10, 5, 7};
            //for (int i = 0; i < nResources; i++) { resources[i] = Integer.parseInt(args[i].trim()); }

            Bank theBank = new BankImpl(resources);
            int[] maxDemand = new int[3];
            int[] allocated = new int[3];

            Thread[] workers = new Thread[Customer.COUNT];      // the customers
            String line;
            try {
                BufferedReader inFile = new BufferedReader(new FileReader("/Users/Tram-AnhTran/Desktop/BankerProblem/src/infile.txt"));
                int threadNum = 0;
                int resourceNum = 0;

                for (int i = 0; i < Customer.COUNT; i++) {
                    line = inFile.readLine();
                    StringTokenizer tokens = new StringTokenizer(line, ",");
                    int count = 0;
                    int[] temp = new int[6];
                    while (tokens.hasMoreTokens()) {
                        String s = tokens.nextToken().trim();
                        int amt = Integer.parseInt(s);
                        temp[count] = amt;
                        count++;
                    }
                    System.arraycopy(temp, 0, allocated, 0, 3);
                    System.arraycopy(temp, 3, maxDemand, 0, 3);
                    count = 0;
                    workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));
                    theBank.addCustomer(threadNum, allocated, maxDemand);


                    threadNum++;        //theBank.getCustomer(threadNum);
                }


            } catch (FileNotFoundException fnfe) {
                throw new Error("Unable to find file \"" + filename + "\"");
            } catch (IOException ioe) {
                throw new Error("Error processing \"" + filename + "\"");
            }

            System.out.println("FACTORY: created threads");     // start the customers

            for (int i = 0; i < Customer.COUNT; i++) {
                workers[i].start();
            }
            System.out.println("FACTORY: started threads");

            System.out.println("* for state, RQ || RL <customer number> <resource #1> <#2> <#3>");
            BufferedReader cl = new BufferedReader(new InputStreamReader(System.in));
            int[] requests = new int[3];
            String requestLine;

            while ((requestLine = cl.readLine()) != null) {

                if (requestLine.equals(""))
                    continue;

                if (requestLine.equals("*")) {
                    theBank.getState();
                    System.out.println("* for state, RQ || RL <customer number> <resource #1> <#2> <#3>");
                }
                else {
                    StringTokenizer tokens = new StringTokenizer(requestLine);
                    String trans = tokens.nextToken().trim();
                    int custNum = Integer.parseInt(tokens.nextToken().trim());
                    for (int i = 0; i < 3; i++) {
                        resources[i] = Integer.parseInt(tokens.nextToken().trim());
                        System.out.println("*" + resources[i] + "*");
                    }

                    if (trans.equals("RQ")) {  // request
                        if (theBank.requestResources(custNum, resources)) {
                            theBank.getState();
                            System.out.println("Approved");
                        } else {
                            System.out.println("Denied");
                        }
                    } else if (trans.equals("RL")) { // release
                        theBank.releaseResources(custNum, resources);
                        theBank.getState();
                    }
                    else // illegal request
                        System.err.println("Must be either 'RQ' or 'RL'");
                }
            }
        }
    }
